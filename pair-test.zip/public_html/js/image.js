const imageUrls = ["https://files.catbox.moe/4rhbav.jpg", "https://files.catbox.moe/4rhbav.jpg", "https://files.catbox.moe/4rhbav.jpg", "https://files.catbox.moe/4rhbav.jpg", "https://files.catbox.moe/4rhbav.jpg", "https://files.catbox.moe/4rhbav.jpg"];
function getRandomImage() {
  const _0x58f1c5 = Math.floor(Math.random() * imageUrls.length);
  return imageUrls[_0x58f1c5];
}
const randomImageElement = document.getElementById("randomImage");
randomImageElement.src = getRandomImage();